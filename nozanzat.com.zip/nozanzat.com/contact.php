<?php
if(isset($_POST['submit']))
{
    include("connetion.php");
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    
    	$i="INSERT INTO `contact` (`name`, `email`, `subject`, `message`) VALUES ('$name', '$email', '$subject', '$message') ";
					$in=mysqli_query($con,$i);
					if($in==1)
					{
					   echo ("<script LANGUAGE='JavaScript'>
					window.alert('Your Message Send Successfully');
					window.location.href='http://nozanzat.com/';
					</script>");
					}
					else{
					    echo "Failed";
					}
}
?>