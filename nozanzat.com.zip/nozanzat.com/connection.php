<?php
$con=mysqli_connect('localhost','trivikr1_zanzat','E4dE=up%#3xY','trivikr1_zanzat') or die("error");
?>