<?php
session_start();
?>
<?php
if(isset($_POST['submit']))
{
include('connection.php');
$name=$_POST['name'];
$email=$_POST['email'];
$date=date('d:m:y');
$contact=$_POST['contact'];
$qty=$_POST['qty'];
$menu=$_POST['drop'];
$loc1='loc1';
$menu1=$_POST['term'];
$address=$_POST['address'];

	if($menu==$loc1)
	{
				$price=$menu1*$qty;
				 $i="INSERT INTO `order` (`name`, `email`, `contact`, `qty`, `menu`, `menu1`, `price`, `address`, `date`) VALUES ('$name', '$email', '$contact', '$qty', '$menu', '$menu1', '$price', '$address', '$date') ";
			$in=mysqli_query($con,$i);
			if($in==1)
			{
			   echo ("<script LANGUAGE='JavaScript'>
			window.alert('Your Order is Confirmed 1');
			window.location.href='http://nozanzat.com/';
			</script>");
			
			$to = $email;
$from = 'info@nozanzat.com'; 
$fromName = "NO ZANZAT" ; 
$subject = "Order Confirm" ; 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
// $headers .= 'Cc: welcome@example.com' . "\r\n"; 
$headers .= 'Bcc: order@nozanzat.com' . "\r\n"; 
$htmlContent = "
<html>
<head>
<title>NO ZANZAT</title>
</head>
<body>
<div style='border: 1px solid #0D4855; width: 100%; background: #f0f1f3; padding: 50px 0px;'>
<div style='width: 75%; background: #fff; padding: 50px 30px; margin: 0 auto;'>
<div style='background: #f97579; padding: 10px;'>
<center><img class='aligncenter' style='height: auto; width: 40%;' src='https://nozanzat.com/logo.PNG' /></center></div>
<h3 style='padding: 10px; text-align: center;'><strong>Order Confirm</strong></h3>
<p style='padding: 10px; text-align: center;'><span style='background-color: #ffffff;'>We have received your order successfully and our delivery executive will contact you soon to picked up your order!
You can find your order information below and can track your order through register mobile number 
</span></p>
</br></br>
<center>
<a hre='' style='background: #f97579;color:white;padding:7px;' >Track Order</a>
<h3 style='padding: 10px; text-align: center;'><strong>Order Summery</strong></h3>

<table>

<tr>
<th style='text-align:left;'>Order Date</th>
<td  style='text-align:right;'>$date</td>
</tr>
<tr>
<th style='text-align:left;'>Customer Name</th>
<td  style='text-align:right;'>$name</td>
</tr>
<tr>
<th style='text-align:left;'>Email ID</th>
<td  style='text-align:right;'>$email</td>
</tr>
<tr>
<th style='text-align:left;'>Contact Number</th>
<td  style='text-align:right;'>$contact</td>
</tr>
<tr>
<th style='text-align:left;'>Quantity</th>
<td  style='text-align:right;'>$qty</td>
</tr>
<tr>
<th style='text-align:left;'>Price</th>
<td  style='text-align:right;'>$price</td>
</tr>
</table>
</center>
<p style='text-align: center;'></p>
<p style='background-color: #ffffff;'> </p>


</div>
<center style='font-size: 12px; color: gray; margin-top: 10px;'>Copyright © 2021 NOZANZAT</center></div>
</body>
</html>
";
mail($to, $subject, $htmlContent, $headers);
			

			}
			else{
				echo "Failed";
			}
	}
	else{		
					
				$price=$menu*$qty;
					$i="INSERT INTO `order` (`name`, `email`, `contact`, `qty`, `menu`, `menu1`, `price`, `address`, `date`) VALUES ('$name', '$email', '$contact', '$qty', '$menu', '$menu1', '$price', '$address', '$date') ";
					$in=mysqli_query($con,$i);
					if($in==1)
					{
					   echo ("<script LANGUAGE='JavaScript'>
					window.alert('Your Order is Confirmed');
					window.location.href='http://nozanzat.com/';
					</script>");
					
					$to = $email;
$from = 'info@nozanzat.com'; 
$fromName = "NO ZANZAT" ; 
$subject = "Order Confirm" ; 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
// $headers .= 'Cc: welcome@example.com' . "\r\n"; 
$headers .= 'Bcc: order@nozanzat.com' . "\r\n"; 
$htmlContent = "
<html>
<head>
<title>NO ZANZAT</title>
</head>
<body>
<div style='border: 1px solid #0D4855; width: 100%; background: #f0f1f3; padding: 50px 0px;'>
<div style='width: 75%; background: #fff; padding: 50px 30px; margin: 0 auto;'>
<div style='background: #f97579; padding: 10px;'>
<center><img class='aligncenter' style='height: auto; width: 40%;' src='https://nozanzat.com/logo.PNG' /></center></div>
<h3 style='padding: 10px; text-align: center;'><strong>Order Confirm</strong></h3>
<p style='padding: 10px; text-align: center;'><span style='background-color: #ffffff;'>We have received your order successfully and our delivery executive will contact you soon to picked up your order!
You can find your order information below and can track your order through register mobile number 
</span></p>
</br></br>
<center>
<a hre='' style='background: #f97579;color:white;padding:7px;' >Track Order</a>
<h3 style='padding: 10px; text-align: center;'><strong>Order Summery</strong></h3>

<table>

<tr>
<th style='text-align:left;'>Order Date</th>
<td  style='text-align:right;'>$date</td>
</tr>
<tr>
<th style='text-align:left;'>Customer Name</th>
<td  style='text-align:right;'>$name</td>
</tr>
<tr>
<th style='text-align:left;'>Email ID</th>
<td  style='text-align:right;'>$email</td>
</tr>
<tr>
<th style='text-align:left;'>Contact Number</th>
<td  style='text-align:right;'>$contact</td>
</tr>
<tr>
<th style='text-align:left;'>Address</th>
<td  style='text-align:right;'>$address</td>
</tr>
<tr>
<th style='text-align:left;'>Quantity</th>
<td  style='text-align:right;'>$qty</td>
</tr>
<tr>
<th style='text-align:left;'>Price</th>
<td  style='text-align:right;'>$price</td>
</tr>
</table>
</center>
<p style='text-align: center;'></p>
<p style='background-color: #ffffff;'> </p>


</div>
<center style='font-size: 12px; color: gray; margin-top: 10px;'>Copyright © 2021 NOZANZAT</center></div>
</body>
</html>
";
mail($to, $subject, $htmlContent, $headers);
					

					}
					else{
						echo "Failed";
					}
			}

}
?>