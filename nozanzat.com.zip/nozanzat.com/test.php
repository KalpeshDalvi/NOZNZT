<?php
     
	$to = 'potemanoj58@gmail.com';
$from = 'info@nozanzat.com'; 
$fromName = "NO ZANZAT" ; 
$subject = "Order Confirm" ; 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
// $headers .= 'Cc: welcome@example.com' . "\r\n"; 
// $headers .= 'Bcc: welcome2@example.com' . "\r\n"; 
$htmlContent = "
<html>
<head>
<title>NO ZANZAT</title>
</head>
<body>
<div style='border: 1px solid #0D4855; width: 100%; background: #f0f1f3; padding: 50px 0px;'>
<div style='width: 75%; background: #fff; padding: 50px 30px; margin: 0 auto;'>
<div style='background: #f97579; padding: 10px;'>
<center><img class='aligncenter' style='height: auto; width: 40%;' src='http://nozanzat.com/demo/assets/img/logo.png' /></center></div>
<h3 style='padding: 10px; text-align: center;'><strong>Order Confirm</strong></h3>
<p style='padding: 10px; text-align: center;'><span style='background-color: #ffffff;'>We have received your order successfully and our delivery executive will contact you soon to picked up your order!
You can find your order information below and can track your order through register mobile number 
</span></p>
</br></br>
<center>
<a hre='' style='background: #f97579;color:white;padding:7px;' >Track Order</a>
<h3 style='padding: 10px; text-align: center;'><strong>Order Summery</strong></h3>

<table>
<tr>
<th style='text-align:left;'>Order Number</th>
<td style='text-align:right;'>#123</td>
</tr>
<tr>
<th style='text-align:left;'>Order Date</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Customer Name</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Email ID</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Contact Number</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Category</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Quantity</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
<tr>
<th style='text-align:left;'>Price</th>
<td  style='text-align:right;'>Order Date</td>
</tr>
</table>
</center>
<p style='text-align: center;'></p>
<p style='background-color: #ffffff;'> </p>


</div>
<center style='font-size: 12px; color: gray; margin-top: 10px;'>Copyright © 2021 NOZANZAT</center></div>
</body>
</html>
";
if(mail($to, $subject, $htmlContent, $headers))
{
    echo "Success";
}
else{
        echo "unSuccess";
}
?>