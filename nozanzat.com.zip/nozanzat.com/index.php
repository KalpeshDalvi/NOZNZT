<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <!-- Global site tag (gtag.js) - Google Analytics -->
 <script async src="https://www.googletagmanager.com/gtag/js?id=G-ZQFD3J5GPT"></script>
 <script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
 
   gtag('config', 'G-ZQFD3J5GPT');
 </script>
 
 <!-- Facebook Pixel Code -->
 <script>
 !function(f,b,e,v,n,t,s)
 {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
 n.callMethod.apply(n,arguments):n.queue.push(arguments)};
 if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
 n.queue=[];t=b.createElement(e);t.async=!0;
 t.src=v;s=b.getElementsByTagName(e)[0];
 s.parentNode.insertBefore(t,s)}(window,document,'script',
 'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '936155716918341'); 
 fbq('track', 'PageView');
 </script>
 <noscript>
  <img height="1" width="1" 
 src="https://www.facebook.com/tr?id=936155716918341&ev=PageView
 &noscript=1"/>
 </noscript>
 <!-- End Facebook Pixel Code -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>NoZanzat </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v1.2.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<style media="screen">
.hide  {
    display: none;
 }
</style>
<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:info@NoZanzat.com">info@NoZanzat.com</a>
        <i class="icofont-phone"></i> +91 7040172219 / 9172184448
      </div>
      <div class="social-links">
        <a href="https://twitter.com/NoZanzat" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="https://www.instagram.com/nozanzat/" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="skype"><i class="icofont-skype"></i></a>
        <a href="https://www.linkedin.com/company/nozanzat/" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.php" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">HOME</a></li>
          <li><a href="#about">ABOUT</a></li>
          <li><a href="#services">SERVICES</a></li>
          <li><a href="#contact">CONTACT</a></li>
          <li><a href="#pricing">PRICING</a></li>
          <li><a href="order.php"   >OREDR STATUS</a></li>
          <li style="" style=""><a href="#book" style="color:#e41d24;" style="" data-toggle="modal"  data-target="#exampleModal">BOOK A PICKUP</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
  
 
<!-- Button trigger modal -->

<!-- Modal -->
<div id="book">
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header" style="background:#E41D24;color:white;">
        <h5 class="modal-title">BOOK A PICKUP</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top:5px;">
          <span aria-hidden="true" style="background:#E41D24;color:white;">&times;</span>
        </button>
      </div>
      <div class="modal-body">
   

		<form method="POST"  id="myform" action="bookorder.php" style="padding:20px;">
		    
  
  <div class="form-group">
    <label for="exampleInputPassword1">Category</label>
   <select id="location"  class="form-control"  name="drop">
 <option value="15">Wash & Iron</option>
 <option value="12.5">Wash & Fold</option>
 <option value="loc1">Dry Cleaning</option>
<option value="12">Ironing</option>
</select>
  </div>
  <div id="first">

 </div>
<div id="second">
<select name="term" class="form-control mb-3" >
  <optgroup label="MEN'S CLOTHING PRICE">
    <option value="49">Shirt</option>
    <option value="49">T-shirt</option>
    <option value="49">Trouser</option>
    <option value="199">Suit(2 piece) </option>
    <option value="199">Suit(3 piece) </option>
    <option value="159">Jacket-Light </option>
    <option value="199">Jacket-medium  </option>
    <option value="199">Jacket-Heavy </option>
    <option value="49">Kurta-Light  </option>
    <option value="89">Kurta-Medium </option>
    <option value="149">Kurta-Heavy </option>
    <option value="49">Payjama  </option>
    <option value="349">Leather Jacket -Heavy  </option>
  </optgroup>
    <optgroup label="WOMEN'S CLOTHING PRICE ">
    <option value="49">Top-Light</option>
    <option value="49">Top-Medium </option>
    <option value="89">Top-Long </option>
    <option value="199">Skirt-Medium</option>
    <option value="199">Skirt-Long </option>
    <option value="89">Blouse</option>
    <option value="149">Blouse-Heavy </option>
    <option value="119">Saree-Plain </option>
    <option value="149">Saree zari-Light </option>
    <option value="249">Saree zari-medium </option>
    <option value="299">Saree zari-Heavy  </option>
    <option value="49">Dupatta </option>
    <option value="49">Kurta-Plain </option>
    <option value="89">Kurta-Fancy</option>
  </optgroup>
    <optgroup label="WOLENS PRICE ">
    <option value="89">Sweater -Light</option>
    <option value="119">sweater-Medium  </option>
    <option value="159">Sweater-Heavy  </option>
    <option value="119">swaet shirt </option>
    <option value="159">Overcoat-Light</option>
    <option value="299">Overcoat-Heavy </option>
    <option value="89">Shawl-Light </option>
    <option value="119">Shawl-Medium </option>
    <option value="159">Shawl-Heavy  </option>
    <option value="89">Cardigan  </option>
    <option value="199">Blanket/Quilt-Single </option>
    <option value="299">blanket/Quilt-double uilt-Double  </option>
    <option value="119">winter wear on ar on Kg  </option>
  </optgroup>
    <optgroup label="NON WEARABLE HOUSEHOLD ITEMS  ">
    <option value="119">Bedsheet-Single </option>
    <option value="159">Bedsheet-Double  </option>
    <option value="120">Curtains-Window  </option>
    <option value="199">Curtains-Door  </option>
  </optgroup>
       </select>
 </div>
<div id="third">

 </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" pattern="[a-zA-Z-]*"  onkeyup="lettersOnly(this)" oninvalid="setCustomValidity('Please enter on alphabets only. ')" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name" placeholder="Enter Name" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email ID</label>
    <input type="email" class="form-control" name="email" id="exampleInputPassword1" placeholder="Enter Email ID" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Contact Number</label>
 <input type="Number"  pattern="[1-9]{1}[0-9]{9}" class="form-control" name="contact" id="exampleInputPassword1" placeholder="Enter Contact Number" required>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Qty (Minimum order of 2kg=8 Cloths )</label>
    <input type="Number" class="form-control" name="qty" id="exampleInputPassword1" placeholder="Enter Clothes Qty" min="8" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Full Address</label>
    <textarea type="Text" class="form-control" name="address" id="exampleInputPassword1" placeholder="Enter Address" required>
	</textarea>
  </div>
  <button type="submit" class="btn btn-block" name="submit" style="background:#E41D24;color:white;">Submit</button>
</form>


<script>
function lettersOnly(input) {
    var regex = /[^a-z]/gi;
    input.value = input.value.replace(regex, "");
}
</script>

<script>
(function() {
   'use strict';
   /* jshint browser: true */

   var d=document;
   var mf=d.getElementById('myform');
   var fe=d.getElementById('first');
   var se=d.getElementById('second');
   var se1=d.getElementById('third');
   var lo=d.getElementById('location')
   var temp;

   mf.reset();
   fe.className='hide';
   se.className='hide';
   se1.className='hide';
   lo.onchange=function() {
if(this.value==='loc1') {
   se.className=se.className.replace('hide','');
 }
else {
   temp=this.value;
   se.className='hide';
   mf.reset();
   lo.value=temp;
  }
if(this.value==='loc2') {
   fe.className=fe.className.replace('hide','');
 }
else {
   temp=this.value;
   fe.className='hide';
   mf.reset();
   lo.value=temp;
  }
if(this.value==='loc3') {
   se1.className=se1.className.replace('hide','');
 }
else {
   temp=this.value;
   se1.className='hide';
   mf.reset();
   lo.value=temp;
  }
 };
}());
</script>
      </div>
  
    </div>
  </div>
</div>
</div>



  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <h1>WELCOME TO <span>NOZANZAT</spaN>
      </h1>
      <h2>Agar Life Jini Ho Bina Zanzat! Book a Service at NoZanzat😊</h2>
      <div class="d-flex">
        <a href="#" data-toggle="modal" data-target="#exampleModal" class="btn-get-started scrollto">BOOK A PICKUP</a>
        <a href="https://www.youtube.com/watch?v=2ICcWA9iA5M&feature=youtu.be" class="venobox btn-watch-video" data-vbtype="video" data-autoplay="true"> Watch Video <i class="icofont-play-alt-2"></i></a>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><img src="assets/img/p1.png" style="height:50px;"></div>
              <h4 class="title"><a href="">Pocket Friendly</a></h4>
              <p class="description"><b>What we offering, others can’t just imagen!</b>
			  we care for your earning and obstacles due to COVID19. All your garment care at the cost of just 59/- (Free Delivery and Collection)</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><img src="assets/img/p2.png" style="height:50px;"></div>
              <h4 class="title"><a href="">Unique Process</a></h4>
              <p class="description">We care for your garments and clothing style! End to End process executed by Highly Experience House Hold Professional.
			  we use the hygiene and comfort solution & follow the standard needs to be cascade your clothes</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><img src="assets/img/p3.png" style="height:50px;"></div>
              <h4 class="title"><a href="">Busy Schedule</a></h4>
              <p class="description"><b>We work as per your convenience!</b>
			  Fastest Execution ever anyone offer before, Same day delivery of your cloths within 24 Hrs.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <div class="icon"><img src="assets/img/p4.png" style="height:50px;"></div>
              <h4 class="title"><a href="">At NoZanzat forget your tension!</a></h4>
              <p class="description">Hassle free communication-Support within 15 Min. Order on single click , WhatsApp Support, Free Delivery</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Featured Services Section -->
    <!-- ======= Why Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
             <h3>Why choose us</h3>
       
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="zoom-out" data-aos-delay="100">
        <center>
            <img src="assets/img/1.PNG" class="img-fluid" style="height:100px;"><p>Laundry Insurance </p></center>
          </div>
          <div class="col-lg-4" data-aos="zoom-out" data-aos-delay="100">
        <center>             <img src="assets/img/3.PNG" class="img-fluid" style="height:100px;">  <p>Free Pick-up and Delivery in 24 Hrs.</p></center>
          </div>
          <div class="col-lg-4" data-aos="zoom-out" data-aos-delay="100">
             <center>          <img src="assets/img/2.PNG" class="img-fluid" style="height:100px;"><p>Affordable Prices</p></center>
          </div>
      
        </div>

      </div>
    </section><!-- End Why Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About</h2>
          <h3>Leave your Laundry  <span>Zanzat!</span></h3>
          <p>NoZanzat is an fastest online and House Hold laundry service provider. </p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="zoom-out" data-aos-delay="100">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/img/s1.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/s2.png" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/s3.png" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="100">
           
            <p class="font-italic">
             We are here with Inspired from AatmNirbhar Bhart Scheme announced by Indian Government! With NoZanzat washing company we
			 are generating maximum Job’s and strong resources to every one by joining the community! At NoZanzat you can rest, assured that your precious garment is taken care by house hold professionals and cleaned with best possible care at very low cost which no one can offer and within same day delivery! We at NoZanzat introduced an unique process and unique assets for your care which includes your pocket care and your busy scheduled care -returned to 
			 you with the greatest care, quality and exceptional service and unbeatable cost in market.
            </p>
         
           
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-4 col-md-4">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">782</span>
              <p>Happy Clients</p>
            </div>
          </div>


          <div class="col-lg-4 col-md-4 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-live-support"></i>
              <span data-toggle="counter-up">1,463</span>
              <p>Hours Of Support</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">25</span>
              <p>Hard Workers</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <h3>Check our <span>Services</span></h3>
           </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class=""><img src="assets/img/a1.png" class="img-fluid" style="height:100px;"></div>
              <h4><a href="">Dry Cleaning </a></h4>
              <p>All your sensitive and special wear garments will be individually treated for any stains and then be drycleaned in our imported machines using very safe SOLVENTS. Expect to have your garments premium packed and returned in 5 days. </p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
            <div class=""><img src="assets/img/a2.PNG" class="img-fluid" style="height:100px;"></div>
              <h4><a href="">Premium Laundry </a></h4>
              <p>All your premium wear garments will be washed using premium fabric specific detergents. Stains will be spotted using advanced stain removing techniques before being washed and steam ironed. Expect to have your garments premium packed and returned in 2-3 days. </p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
			<div class=""><img src="assets/img/a3.png" class="img-fluid" style="height:100px;"></div>
              <h4><a href="">Steam Ironing </a></h4>
              <p>No more burnt or stained clothes. We at NoZanzat use an all steam process to remove the wrinkles in your garment. For those who wish to wash their clothes at home and yet wear crisp finished garments can use our steam ironing service. Expect to have your garments returned in 2-3 days. </p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
             <div class=""><img src="assets/img/a4.png" class="img-fluid"  style="height:100px;"></div>
              <h4><a href="">Wash & Iron (Unit Basis) </a></h4>
              <p>Just have a few garments to be washed? We can handle this as well. Expect to have your garments returned in 24 Hours. </p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
            <div class=""><img src="assets/img/a5.png" class="img-fluid"  style="height:100px;"></div>
              <h4><a href="">Wash & Iron (Kg Basis) </a></h4>
              <p>All your regular wear garments will be washed, steam ironed and neatly packed for delivery. Expect to have your garments returned in  24 Hours. </p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
             <div class=""><img src="assets/img/a6.png" class="img-fluid" style="height:100px;"></div>
              <h4><a href="">Wash & Fold (Kg Basis) </a></h4>
              <p>Just in case you choose not to use our steam ironing services we will wash and fold them for you. Expect to have your garments returned in  24 Hours. </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">

        <div class="owl-carousel testimonials-carousel">

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
            <h3>Dipali Kadam</h3>
            <h4>Client </h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
             Very nice dry cleaning services provided to me. Totally satisfied with their service. I got my Blanket dry cleaned and it was delivered to me on time. Fast and affordable laundry related services. I loved it. Totally recommended place for all Laundry and Dry Cleaning services requirements. They have online ordering as well as Android app to place orders.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
            <h3>Kamal Bora</h3>
            <h4>Client</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
             Very friendly service, they deliver well before the delivery time and quality is really great
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
            <h3>Mohd Salim</h3>
            <h4>Client</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
          superb cleaning, one of the best near my place. affordable prices and crazy cool packaging. I love giving my clothes for washing, iron and dry cleaning. they never upset me with there quality. staff is very friendly. their commitment towards their job is incredible. Best of luck guys for you future endeavours.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
            <h3>Shikrant Desai</h3>
            <h4>Client</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Satisfied with their service and also with their timing, got my clothes washed within the time limit, really good experience with them
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
            <h3>Keshav Mane</h3>
            <h4>Client</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
           Best laundary service ever. Great and amazing  experience and service at a very and unbleivable affordable price.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

        </div>

      </div>
    </section><!-- End Testimonials Section -->



    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Pricing</h2>
          <h3>Check our <span>Pricing</span></h3>
           </div>

        <div class="row">

          <div class="col-lg-4 col-md-4" data-aos="fade-up" data-aos-delay="100">
            <div class="box featured">
              <h3>Wash & Fold </h3>
              <h4><sup>Just @</sup>49<span> / 1Kg</span></h4>
              <ul>
                <li>Just in case you choose not to use our steam ironing services we will wash and fold them for you. And deliver them in same day within 24 Hrs!</li>
             
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy"  data-toggle="modal" data-target="#exampleModal">Book Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box featured">
              <h3>Wash & Iron</h3>
              <h4><sup>Just @</sup>59<span> / 1Kg</span></h4>
              <ul>
                <li>All your regular wear garments will be washed, steam ironed and neatly packed for free delivery. And deliver them in same day within 24 Hrs!</li>
               
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy"  data-toggle="modal" data-target="#exampleModal">Book Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box featured">
              <h3>Wash & Iron</h3>
              <h4><sup></sup><span> Unit Basis</span></h4>
              <ul>
                <li>    Just have a few garments to be washed? We can handle this as well. And deliver them in same day within 24 Hrs! </li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy"  data-toggle="modal" data-target="#exampleModal">Book Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-12 col-md-12 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <div class="box featured">
              <h3>Dry Cleaning</h3>
             <div>
                 <div class="row">
                     
             <div class="col-md-6">
               <h2 style="color:#E41D24;font-size:20px;">		MEN'S CLOTHING PRICE 	</h2>
          <table class="table table-striped table-sm">
              <tr>
                  <th>Shirt</th>
                  <td>Rs. 49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>T-shirt	</th>
                  <td>Rs. 49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Trouser	</th>
                  <td>Rs. 49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Suit(2 piece)	</th>
                  <td>Rs.199</td>
                  </tr>
              <tr>
                  <th>Suit(2 piece)	</th>
                  <td>Rs.199</td>
                  </tr>
              <tr>
                  <th>Suit(3 piece)		</th>
                  <td>Rs.199</td>
                  </tr>
              <tr>
                  <th>Jacket-Light	</th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>Jacket-Light	</th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>Jacket-medium	</th>
                  <td>Rs.199/piece</td>
                  </tr>
              <tr>
                  <th>Jacket-Heavy	</th>
                  <td>Rs.199/piece</td>
                  </tr>
              <tr>
                  <th>Kurta-Light		</th>
                  <td>Rs. 49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Kurta-Medium	</th>
                  <td>	Rs. 89</td>
                  </tr>
              <tr>
                  <th>Kurta-Medium	</td>
                  <td>	Rs. 89</td>
                  </tr>
              <tr>
                  <th>Kurta-Heavy	</th>
                  <td>	Rs.149/piece</td>
                  </tr>
              <tr>
                  <th>Payjama			</th>
                  <td>Rs.49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Leather Jacket -Heavy 		</th>
                  <td>Rs.349/piece</td>
                  </tr>
              </table>
              </div>
             <div class="col-md-6">
           <h2 style="color:#E41D24;font-size:20px;">		WOMEN'S CLOTHING PRICE 	</h2>
          <table class="table table-striped table-sm">
              <tr>
                  <th>Top-Light		</th>
                  <td>Rs.49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Top-Medium	</th>
                  <td>Rs.49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Top-Long	</th>
                  <td>Rs.89/piece</td>
                  </tr>
              <tr>
                  <th>Skirt-Medium	</th>
                  <td>Rs.199</td>
                  </tr>
              <tr>
                  <th>Skirt-Long		</th>
                  <td>Rs.199</td>
                  </tr>
              <tr>
                  <th>Blouse	</th>
                  <td>Rs.89/piece</td>
                  </tr>
              <tr>
                  <th>Blouse-Heavy	</th>
                  <td>Rs.149/piece</td>
                  </tr>
              <tr>
                  <th>Saree-Plain 	</th>
                  <td>Rs.119/piece</td>
                  </tr>
              <tr>
                  <th>Saree zari-Light	</th>
                  <td>Rs.149/piece</td>
                  </tr>
              <tr>
                  <th>Saree zari-medium	</th>
                  <td>Rs.249/piece</td>
                  </tr>
              <tr>
                  <th>Saree zari-Heavy	</th>
                  <td>Rs.299/piece</td>
                  </tr>
              <tr>
                  <th>Dupatta			</th>
                  <td>Rs.49/piece</td>
                  </tr>
              <tr>
                  <th>Kurta-Plain			</td>
                  <td>Rs.49/piece(min order 149)</td>
                  </tr>
              <tr>
                  <th>Kurta-Fancy</th>
                  <td>Rs.89/piece</td>
                  </tr>
            
              </table>
              </div>
              </div>
                 <div class="row">
                     
             <div class="col-md-6">
             <h2 style="color:#E41D24;font-size:20px;">	WOLENS PRICE	</h2>
          <table class="table table-striped table-sm">
              <tr>
                  <th>Sweater -Light</th>
                  <td>Rs.89/piece</td>
                  </tr>
              <tr>
                  <th>sweater-Medium		</th>
                  <td>Rs.119/piece</td>
                  </tr>
              <tr>
                  <th>Sweater-Heavy	</th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>swaet shirt		</th>
                  <td>Rs.119/piece</td>
                  </tr>
              <tr>
                  <th>Overcoat-Light</th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>Overcoat-Heavy 		</th>
                  <td>Rs.299/piece</td>
                  </tr>
              <tr>
                  <th>Shawl-Light 	</th>
                  <td>Rs.89/piece</td>
                  </tr>
              <tr>
                  <th>Shawl-Medium	</th>
                  <td>Rs.119/piece</td>
                  </tr>
              <tr>
                  <th>Shawl-Heavy		</th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>Cardigan	</th>
                  <td>Rs.89/piece</td>
                  </tr>
              <tr>
                  <th>Blanket/Quilt-Single	</th>
                  <td>Rs.199/piece</td>
                  </tr>
              <tr>
                  <th>blanket/Quilt-double	uilt-Double	</th>
                  <td>	Rs.299/piece</td>
                  </tr>
              <tr>
                  <th>winter wear on	ar on Kg</td>
                  <td>Rs.119/kg</td>
                  </tr>
              
              </table>
              </div>
             <div class="col-md-6">
                 <h2 style="color:#E41D24;font-size:20px;">	NON WEARABLE HOUSEHOLD ITEMS </h2>
          <table class="table table-striped table-sm">
              <tr>
                  <th>Bedsheet-Single 	</th>
                  <td>Rs.119/piece</td>
                  </tr>
              <tr>
                  <th>Bedsheet-Double </th>
                  <td>Rs.159/piece</td>
                  </tr>
              <tr>
                  <th>Curtains-Window	</th>
                  <td>Rs.120 per panel</td>
                  </tr>
              <tr>
                  <th>Curtains-Door 	</th>
                  <td>Rs.199 per panel </td>
                  </tr>
            
              </table>
              </div>
              </div>
              
              </div>
              <div class="btn-wrap">
                <a href="#" class="btn-buy"  data-toggle="modal" data-target="#exampleModal">Book Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->


    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <h3><span>Get in Touch</span></h3>
          </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-4">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>Pune city</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-4">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>info@nozanzat.com</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-4">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+91 9172184448 </p>
            </div>
          </div>

        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-12 ">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.312824488532!2d73.9292009148934!3d18.55993028738602!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTjCsDMzJzM1LjgiTiA3M8KwNTUnNTMuMCJF!5e0!3m2!1sen!2sin!4v1604244455673!5m2!1sen!2sin" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>  </div>

        

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3><a href="index.php" class="logo mr-auto"><img src="assets/img/logo.png" alt="" style="height:50px"></a></h3>
            <p>
              Pune city <br><br>
              <strong>Phone:</strong> +91 7040172219 / 9172184448<br>
              <strong>Email:</strong> info@nozanzat.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Dry Cleaning </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Premium Laundry </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Steam Ironing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Iron (Unit Basis) </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Iron (Kg Basis) </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Fold (Kg Basis)  </a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
           <a href=""> <img src="assets/img/hh.png" alt="" class="img-fluid"></a>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="https://www.facebook.com/NoZanzat/?notif_id=1610558654572661&notif_t=page_fan&ref=notif" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="https://www.instagram.com/nozanzat/?fbclid=IwAR0X2OO3c7B57VfZNtJ5PIvcKRSjMXOoJ-ekVpXp7u1V9ywQurxOBkkqb58" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="https://www.linkedin.com/company/nozanzat/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>NOZANZAT</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://itplanet.in/">ITPLANET</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
<Script type="text/javascript">
$(document).ready(function()
{
    
$('body').bind('cut copy paste',function (e) {
    
    e.preventionDefault();
    
})
$("body").on("contextmenu", function(e){
    return false;
})
})
</Script>
</html>