<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>NoZanzat </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v1.2.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:info@NoZanzat.com">info@NoZanzat.com</a>
        <i class="icofont-phone"></i> +91 7040172219
      </div>
      <div class="social-links">
        <a href="https://www.facebook.com/NoZanzat/" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="skype"><i class="icofont-skype"></i></a>
        <a href="https://www.facebook.com/NoZanzat/" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.php" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li class="active"><a href="order.php"   >Order Status</a></li>
          <li style="" style=""><a href="index.php" style="color:#e41d24;" >BOOK A PICKUP</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
  
 
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header" style="background:#E41D24;color:white;">
        <h5 class="modal-title">BOOK A PICKUP</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="background:#E41D24;color:white;">&times;</span>
        </button>
      </div>
      <div class="modal-body">
   

		<form method="POST" action="bookorder.php" style="padding:20px;">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name" placeholder="Enter Name" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email ID</label>
    <input type="email" class="form-control" name="email" id="exampleInputPassword1" placeholder="Enter Email ID" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Contact Number</label>
    <input type="Number" class="form-control" name="contact" id="exampleInputPassword1" placeholder="Enter Contact Number" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Category</label>
    <select type="text" class="form-control" name="menu" id="exampleInputPassword1" placeholder="Enter Contact Number" required>
        <option value="15">Wash & Iron</option>
        <option value="12.5">Wash & Fold</option>
        </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Qty (Minimum order of 2kg / 8 Cloths )</label>
    <input type="Number" class="form-control" name="qty" id="exampleInputPassword1" placeholder="Enter Qty" min="8" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Address</label>
    <textarea type="Text" class="form-control" name="address" id="exampleInputPassword1" placeholder="Enter Address" min="8" required>
	</textarea>
  </div>
  <button type="submit" class="btn btn-block" name="submit" style="background:#E41D24;color:white;">Submit</button>
</form>
      </div>
  
    </div>
  </div>
</div>



  <!-- ======= Hero Section ======= -->
  <section id="" class="">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
    <form method="POST" action="" style="padding:20px;">


<div class="row">
<div class="col-md-4"></div>
<div class="col-md-4">
    <h1>Order <span>Status</spaN></h1>
		<form method="POST" action="" style="padding:20px;">

  <div class="form-group">
    <label for="exampleInputPassword1">Contact Number</label>
    <input type="Number" class="form-control" name="contact" id="exampleInputPassword1" placeholder="Enter Contact Number" required>
  </div>

  <button type="submit" class="btn btn-block" name="submit" style="background:#E41D24;color:white;">Check Status</button>
</form>
</div>
</div>
<div class="table-responsive">
<table class="table table-striped table-sm">
    <?php 
    if(isset($_POST['submit']))
    {
    ?>
              <tr>
                  <th>Order No.</th>
                  <th>Order Date</th>
                  <th>Qty</th>
                  <th>Price</th>
                  </tr>
                  <?php
                  include('connection.php');
                  $contact=$_POST['contact'];
                  $s="SELECT * FROM `order` WHERE `contact`='$contact'";
                  $ss=mysqli_query($con,$s);
                  while($sss=mysqli_fetch_array($ss))
                  {
                  ?>
                  <tr>
                     <td><?php echo 'NZ#'.$sss['id'];?></td>
                     <td><?php echo $sss['date'];?></td>
                     <td><?php echo $sss['qty'];?></td>
                     <td><?php echo $sss['price'];?></td>
                     </tr>
                <?php }}?>

       
              </table>
      </div>
    </div>
  </section><!-- End Hero -->




  <!-- ======= Footer ======= -->
  <footer id="footer">

    

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3><a href="index.php" class="logo mr-auto"><img src="assets/img/logo.png" alt="" style="height:50px"></a></h3>
            <p>
              Pune city <br><br>
              <strong>Phone:</strong> +91 7040172219 <br>
              <strong>Email:</strong> info@nozanzat.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Dry Cleaning </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Premium Laundry </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Steam Ironing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Iron (Unit Basis) </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Iron (Kg Basis) </a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Wash & Fold (Kg Basis)  </a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
                <a href=""> <img src="assets/img/hh.png" alt="" class="img-fluid"></a>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>NOZANZAT</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://itplanet.in/">ITPLANET</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>